package com.project.ilearncentral.CustomInterface;

import android.view.View;

public interface CustomOnClickListener {
    void onClick(View view, int position);
}
