package com.project.ilearncentral.CustomInterface;

public interface OnBooleanChangeListener
{
    public void onBooleanChanged(boolean value);
}
