package com.project.ilearncentral.CustomInterface;

public interface OnIntegerChangeListener {
        public void onIntegerChanged(int value);
}
