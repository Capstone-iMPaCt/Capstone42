package com.project.ilearncentral.MyClass;

import com.project.ilearncentral.Model.BankAccountDetail;

import java.util.ArrayList;
import java.util.List;

public class BankAccountList {
    public static List<BankAccountDetail> data = new ArrayList<>();
}
