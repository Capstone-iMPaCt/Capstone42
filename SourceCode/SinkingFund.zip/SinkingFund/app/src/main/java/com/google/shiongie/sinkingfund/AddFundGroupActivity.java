package com.google.shiongie.sinkingfund;

import android.os.Bundle;
import android.util.Log;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.View;
import android.view.ViewParent;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class AddFundGroupActivity extends AppCompatActivity {
		public static final String TAG = "AddFundGroup";
		final String[] values = {"Daily", "Weekly", "Monthly", "Yearly"};
		private DatePicker datePicker;
		private NumberPicker numberPickerRecurrence, numberPickerType;
		private EditText fundName, fundAmount;
		private Button save;

		private EditText memberInput;
		private ImageButton addMember;
		private LinearLayout memberList;
		private FirebaseFirestore db;
		private FirebaseAuth mAuth;
		private FirebaseUser user;
		private Map<String, String> users;
		private Map<String, String> userIds;
		private Map<String, String> addedUsers;
		private Map<Integer, String> ids;

		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.activity_add_fund_group);

				mAuth = FirebaseAuth.getInstance();
				user = mAuth.getCurrentUser();
				db = FirebaseFirestore.getInstance();

				fundName = findViewById(R.id.add_fund_group_name);
				fundAmount = findViewById(R.id.add_fund_group_amount);
				datePicker = findViewById(R.id.add_fund_group_start);
				numberPickerRecurrence = findViewById(R.id.add_fund_group_recurrence_number);
				numberPickerType = findViewById(R.id.add_fund_group_recurrence_type);

				save = findViewById(R.id.add_fund_group_save);

				final Calendar c = Calendar.getInstance();
				int year = c.get(Calendar.YEAR);
				int month = c.get(Calendar.MONTH);
				int day = c.get(Calendar.DAY_OF_MONTH);
				datePicker.setMinDate(System.currentTimeMillis());
				datePicker.updateDate(year, month, day);

				numberPickerRecurrence.setMinValue(1);
				numberPickerRecurrence.setMaxValue(20);
				numberPickerRecurrence.setValue(1);

				numberPickerType.setDisplayedValues(values);
				numberPickerType.setMinValue(0);
				numberPickerType.setMaxValue(values.length - 1);
				numberPickerType.setWrapSelectorWheel(true);

				getSupportActionBar().setDisplayHomeAsUpEnabled(true);

				memberInput = findViewById(R.id.add_fund_group_member_search);
				addMember = findViewById(R.id.add_fund_group_member_add);
				memberList = findViewById(R.id.add_fund_group_member_list);
				users = new HashMap<String, String>();
				userIds = new HashMap<String, String>();
				addedUsers = new HashMap<String, String>();
				ids = new HashMap<Integer, String>();

				memberList.setPadding(10, 10, 10, 0);

				db.collection("users").get()
					.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
							@Override
							public void onComplete(@NonNull Task<QuerySnapshot> task) {
									if (task.isSuccessful()) {
											for (QueryDocumentSnapshot document : task.getResult()) {
													users.put(document.get("email").toString(), document.get("name").toString());
													userIds.put(document.get("email").toString(), document.getId());
											}
									} else {
									}
							}
					});

				if (!addedUsers.containsKey(user.getEmail())) {
						memberInput.setText(user.getEmail());
						addMember.performClick();
				}

				addMember.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(final View v) {
								runOnUiThread(new Runnable() {
										public void run() {
												final String email = memberInput.getText().toString();
												if (users.containsKey(email)) {
														if (!addedUsers.containsKey(email)) {
																RelativeLayout newRow = new RelativeLayout(v.getContext());
																newRow.setGravity(Gravity.LEFT);
																newRow.setId(ids.size());
																ids.put(ids.size(), email);
																newRow.setOnDragListener(new View.OnDragListener() {
																		@Override
																		public boolean onDrag(View v, DragEvent event) {
																				return false;
																		}
																});

																TextView user = new TextView(v.getContext());
																user.setText(users.get(email) + " - " + email);
																RelativeLayout.LayoutParams lp_user = new RelativeLayout.LayoutParams(
																				RelativeLayout.LayoutParams.WRAP_CONTENT,
																				RelativeLayout.LayoutParams.WRAP_CONTENT
																);
																lp_user.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
																user.setLayoutParams(lp_user);

																ImageButton moveDownMember = new ImageButton(v.getContext());
																moveDownMember.setBackground(ContextCompat.getDrawable(v.getContext(), R.drawable.ic_keyboard_arrow_down_black_24dp));
																moveDownMember.setOnClickListener(new View.OnClickListener() {
																		@Override
																		public void onClick(View v) {
																				ViewParent p = v.getParent();
																				int indexOfMyView = memberList.indexOfChild((View) p);
																				if (indexOfMyView < memberList.getChildCount() - 1) {
																						memberList.removeView((View) p);
																						indexOfMyView++;
																						memberList.addView((View) p, indexOfMyView);
																				}
																		}
																});
																RelativeLayout.LayoutParams lp_moveDownMember = new RelativeLayout.LayoutParams(
																				RelativeLayout.LayoutParams.WRAP_CONTENT,
																				RelativeLayout.LayoutParams.WRAP_CONTENT
																);
																lp_moveDownMember.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
																lp_moveDownMember.setMarginEnd(200);
																moveDownMember.setLayoutParams(lp_moveDownMember);

																ImageButton moveUpMember = new ImageButton(v.getContext());
																moveUpMember.setBackground(ContextCompat.getDrawable(v.getContext(), R.drawable.ic_keyboard_arrow_up_black_24dp));
																moveUpMember.setOnClickListener(new View.OnClickListener() {
																		@Override
																		public void onClick(View v) {
																				ViewParent p = v.getParent();
																				int indexOfMyView = memberList.indexOfChild((View) p);
																				if (indexOfMyView > 0) {
																						memberList.removeView((View) p);
																						indexOfMyView--;
																						memberList.addView((View) p, indexOfMyView);
																				}
																		}
																});
																RelativeLayout.LayoutParams lp_moveUpMember = new RelativeLayout.LayoutParams(
																				RelativeLayout.LayoutParams.WRAP_CONTENT,
																				RelativeLayout.LayoutParams.WRAP_CONTENT
																);
																lp_moveUpMember.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
																lp_moveUpMember.setMarginEnd(100);
																moveUpMember.setLayoutParams(lp_moveUpMember);

																ImageButton removeMember = new ImageButton(v.getContext());
																removeMember.setBackground(ContextCompat.getDrawable(v.getContext(), R.drawable.ic_close_black_24dp));
																removeMember.setOnClickListener(new View.OnClickListener() {
																		@Override
																		public void onClick(View v) {
																				memberList.removeView((View) v.getParent());
																				addedUsers.remove(ids.get(((View) v.getParent()).getId()));
																		}
																});
																RelativeLayout.LayoutParams lp_removeMember = new RelativeLayout.LayoutParams(
																				RelativeLayout.LayoutParams.WRAP_CONTENT,
																				RelativeLayout.LayoutParams.WRAP_CONTENT
																);
																lp_removeMember.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
																removeMember.setLayoutParams(lp_removeMember);

																newRow.addView(user);
																newRow.addView(moveDownMember);
																newRow.addView(moveUpMember);
																newRow.addView(removeMember);

																memberList.addView(newRow);

																memberInput.setText("");

																addedUsers.put(email, users.get(email));
														} else {
																Toast.makeText(v.getContext(), "Member already added.",
																				Toast.LENGTH_SHORT).show();
														}
												} else {
														Toast.makeText(v.getContext(), "No member with email found.",
																		Toast.LENGTH_SHORT).show();
												}
										}
								});
						}
				});

				save.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v) {
								new Thread(new Runnable() {
										public void run() {
												String fundName = AddFundGroupActivity.this.fundName.getText().toString();
												if (!(fundName.isEmpty() || fundAmount.getText().toString().isEmpty())) {
														// adds to groupFund Collection
														if (!addedUsers.isEmpty()) {
																Map<String, Object> data = new HashMap<>();
																String recurrenceType = values[numberPickerType.getValue()];
																int recurrenceTime = numberPickerRecurrence.getValue();
																float amount = Float.parseFloat(fundAmount.getText().toString());

																data.put("name", fundName);
																data.put("amount", amount);
																data.put("recurrenceTime", recurrenceTime);
																data.put("recurrenceType", recurrenceType);
																Calendar c = Calendar.getInstance();
																data.put("dateCreated", c.getTime());
																c.set(datePicker.getYear(), datePicker.getMonth(), datePicker.getDayOfMonth());
																data.put("dateStart", c.getTime());
																data.put("status", "active");

																data.put("description", recurrenceTime + "x "
																				+ recurrenceType + " Remittance of "
																				+ Utility.currencyFormat(amount));


																int memberCount = memberList.getChildCount();

																Date curD = Calendar.getInstance().getTime();
																Calendar cD = Calendar.getInstance();
																Date s = c.getTime();
																cD.setTime(s);
																cD = Utility.addDate(cD, recurrenceType, memberCount - 1 / recurrenceTime);
																Date e = cD.getTime();
																data.put("duration", Utility.dateFormat(s) + " - " + Utility.dateFormat(e));
																data.put("dateEnd", e.getTime());
																if (curD.before(s)) {
																		data.put("star", "-1");
																} else if (s.after(curD) && curD.before(e)) {
																		data.put("star", "0");
																} else {
																		data.put("star", "1");
																}

																ArrayList<Map> members = new ArrayList<>();
																for (int i = 0; i < memberList.getChildCount(); i++) {
																		Map<String, Object> member = new HashMap<>();
																		String email = ids.get(memberList.getChildAt(i).getId());
																		if (user.getEmail().equals(email) || addedUsers.size() == 1)
																				member.put("admin", true);
																		else
																				member.put("admin", false);
																		member.put("id", userIds.get(email));
																		member.put("email", email);
																		member.put("name", addedUsers.get(email));
																		member.put("received", false);
																		member.put("paymentCount", 0);

																		if (i != 0)
																				c = Utility.addDate(c, recurrenceType, memberCount - 1 / recurrenceTime);

																		member.put("dateReceive", c.getTime());
																		members.add(member);
																}
																data.put("members", members);
																db.collection("groupFunds")
																	.add(data)
																	.addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
																			@Override
																			public void onSuccess(DocumentReference documentReference) {
																					Toast.makeText(AddFundGroupActivity.this, "Successfully Added Fund Group",
																									Toast.LENGTH_SHORT).show();
																					for (int i = 0; i < memberList.getChildCount(); i++) {
																							String email = ids.get(memberList.getChildAt(i).getId());
																							Log.d(TAG, i + " email:" + email);
																					}
																					finish();
																			}
																	})
																	.addOnFailureListener(new OnFailureListener() {
																			@Override
																			public void onFailure(@NonNull Exception e) {
																					Toast.makeText(AddFundGroupActivity.this, "Adding Fund Group Failed",
																									Toast.LENGTH_SHORT).show();
																			}
																	});
														} else {
																Toast.makeText(AddFundGroupActivity.this, "Please add members",
																				Toast.LENGTH_SHORT).show();
														}
												} else {
														Toast.makeText(AddFundGroupActivity.this, "Please add inputs",
																		Toast.LENGTH_SHORT).show();
												}
										}
								}).start();
						}
				});
		}

		public boolean onSupportNavigateUp() {
				finish();
				return true;
		}
}
