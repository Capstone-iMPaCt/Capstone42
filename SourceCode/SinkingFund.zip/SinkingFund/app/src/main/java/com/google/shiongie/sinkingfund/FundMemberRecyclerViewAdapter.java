package com.google.shiongie.sinkingfund;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.Timestamp;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class FundMemberRecyclerViewAdapter extends RecyclerView.Adapter<FundMemberRecyclerViewAdapter.ViewHolder>
{
    public static final String TAG = "FundMemberAdapter";

    private Context mContext;
    private ArrayList<Map<String, Object>> members;

    public FundMemberRecyclerViewAdapter(Context mContext, ArrayList<Map<String, Object>> members)
    {
        this.members = members;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(mContext).inflate(R.layout.fund_view_member_list_item, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position)
    {
        Log.d(TAG, "onBindViewHolder: called.");

        FirebaseStorage storage = FirebaseStorage.getInstance();
        final StorageReference storageRef = storage.getReference();

        final Map<String, Object> member = members.get(position);
        new Thread(new Runnable() {
            public void run() {
                try
                {
                    storageRef.child("images").child(member.get("id").toString()).getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>()
                    {
                        @Override
                        public void onSuccess(Uri uri)
                        {
                            Picasso.get().load(uri.toString()).transform(new CircleTransform()).error(R.drawable.user).into(holder.image);
                        }
                    });
                } catch (Exception e) {}
            }
        }).start();
        holder.number.setText((position+1) + ".) ");
        holder.name.setText((member.containsKey("name")? member.get("name").toString():""));
        holder.email.setText((member.containsKey("email")? member.get("email").toString():""));
        if (!(boolean)member.get("received")) {
            holder.received.setText("To Receive");
        } else {
            try
            {
                String r = "Received - " + Utility.dateFormat((Timestamp) member.get("dateReceive"));
                holder.received.setText(r);
            }catch (Exception e) {
                String r = "Received - " + Utility.dateFormat((Date) member.get("dateReceive"));
                holder.received.setText(r);
            }
        }
        if (member.containsKey("admin")) {
            if ((boolean)member.get("admin")) {
                holder.admin.setText("Admin");
            } else {
                holder.admin.setText("Member");
            }
        }
        holder.parent.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(mContext, ViewPaymentsActivity.class);
                intent.putExtra("TYPE", "both");
                intent.putExtra("USER_EMAIL", member.get("email").toString());
                intent.putExtra("GROUP_FUND_ID", member.get("groupFundId").toString());
                mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount()
    {
        return members.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout parent;
        ImageView image;
        TextView number, name, email, received, admin;

        public ViewHolder(@NonNull View itemView)
        {
            super(itemView);
            parent = itemView.findViewById(R.id.fund_view_parent);
            image = itemView.findViewById(R.id.fv_member_image);
            number = itemView.findViewById(R.id.fv_member_number);
            name = itemView.findViewById(R.id.fv_member_name);
            email = itemView.findViewById(R.id.fv_member_email);
            received = itemView.findViewById(R.id.fv_member_received);
            admin = itemView.findViewById(R.id.fv_member_admin);
        }
    }
}
