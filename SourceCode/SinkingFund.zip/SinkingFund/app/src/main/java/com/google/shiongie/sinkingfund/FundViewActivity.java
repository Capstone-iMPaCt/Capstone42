package com.google.shiongie.sinkingfund;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.Transaction;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class FundViewActivity extends AppCompatActivity
{
    private String TAG = "FUND_GROUP";
    private FirebaseFirestore db;
    private FirebaseUser user;
    private FundMemberRecyclerViewAdapter adapter;

    private String groupFundId;
    private boolean admin;
    private boolean closed;
    private int checkedItem;
    private double amount;

    private ImageView star;
    private TextView name, duration, description, paymentCount;
    private Button addPayment, newReceiver, viewPayments, updateAdmin;

    private Map<String, Object> fundGroup;
    private ArrayList<Map<String, Object>> members;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fund_view);

        Intent intent = getIntent();
        groupFundId = intent.getStringExtra("GROUP_FUND_ID");

        db = FirebaseFirestore.getInstance();
        user = FirebaseAuth.getInstance().getCurrentUser();

        admin = false;
        closed = false;
        checkedItem = 0;
        amount = 0;

        addPayment = findViewById(R.id.fund_view_add_payment);
        newReceiver = findViewById(R.id.fund_view_new_receiver);
        viewPayments = findViewById(R.id.fund_view_payments);
        updateAdmin = findViewById(R.id.fund_view_update_admin);

        star = findViewById(R.id.fund_view_star);
        name = findViewById(R.id.fund_view_name);
        duration = findViewById(R.id.fund_view_duration);
        description = findViewById(R.id.fund_view_description);
        paymentCount = findViewById(R.id.fund_view_payment_count);

        fundGroup = new HashMap<>();
        members = new ArrayList<>();

        addPayment.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                AlertDialog.Builder builder = new AlertDialog.Builder(FundViewActivity.this);
                builder.setTitle("Who paid?");

                final List<String> memberNames = new ArrayList<>();
                checkedItem = 0;
                for (Map<String, Object> member:members)
                {
                    memberNames.add(member.get("email").toString());
                }
                builder.setSingleChoiceItems(memberNames.toArray(new String[memberNames.size()]), checkedItem, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        checkedItem = which;
                    }
                });

                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    Map<String, Object> payment = new HashMap<>();
                    payment.put("groupFundId", groupFundId);
                    payment.put("email", memberNames.get(checkedItem));
                    payment.put("amount", amount);
                    payment.put("datePaid", Calendar.getInstance().getTime());

                    db.collection("payments")
                        .add(payment)
                        .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {
                                getFundGroupData();
                                Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.getId());
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.w(TAG, "Error adding document", e);
                            }
                        });
                    }
                });
                builder.setNegativeButton("Cancel", null);

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        newReceiver.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Map<String, Object> receivingMember = null;
                int i=0;
                for (; i<members.size(); i++) {
                    if (!(boolean)members.get(i).get("received")) {
                        receivingMember = members.get(i);
                        break;
                    }
                }
                if (i == members.size()) closed = true;
                else closed = false;
                final int pos = i;
                final Map<String, Object> finalReceivingMember = receivingMember;
                if (!closed)
                {
                    AlertDialog.Builder alert = new AlertDialog.Builder(FundViewActivity.this);
                    alert.setTitle("New Receiver");
                    alert.setMessage(receivingMember.get("name") + " has received their funds.");

                    alert.setPositiveButton("Yes", new DialogInterface.OnClickListener()
                    {
                        public void onClick(DialogInterface dialog, int id)
                        {
                            setReceived(finalReceivingMember, pos);
                        }
                    });
                    alert.setPositiveButtonIcon(getResources().getDrawable(R.drawable.ic_check_black_24dp));
                    alert.setNegativeButton("No", new DialogInterface.OnClickListener()
                    {
                        @Override
                        public void onClick(DialogInterface dialog, int which)
                        {
                            dialog.cancel();
                        }
                    });
                    alert.setNegativeButtonIcon(getResources().getDrawable(R.drawable.ic_close_black_24dp));

                    Dialog dialog = alert.create();
                    dialog.show();
                } else {
                    setClosedFund();
                }
            }
        });
        updateAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(FundViewActivity.this, UpdateAdminActivity.class);
                intent.putExtra("GROUP_FUND_ID", groupFundId);
                startActivityForResult(intent, 3);
            }
        });

        viewPayments.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(FundViewActivity.this, ViewPaymentsActivity.class);
                intent.putExtra("TYPE", "groupFund");
                intent.putExtra("GROUP_FUND_ID", groupFundId);
                intent.putExtra("USER_EMAIL", "");
                startActivityForResult(intent, 4);
            }
        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.fund_view_member_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new FundMemberRecyclerViewAdapter(this, members);
        recyclerView.setAdapter(adapter);
        adminView();
        getFundGroupData();
    }

    private void setReceived(Map<String, Object> receivingMember, int pos)
    {
        receivingMember.put("received", true);
        receivingMember.put("dateReceive", Calendar.getInstance().getTime());
        members.remove(pos);
        members.add(pos, receivingMember);

        DocumentReference dbRef = db.collection("groupFunds").document(groupFundId);
        dbRef
            .update("members", members)
            .addOnSuccessListener(new OnSuccessListener<Void>()
            {
                @Override
                public void onSuccess(Void aVoid)
                {
                    Log.d(TAG, "DocumentSnapshot successfully updated!");
                    adapter.notifyDataSetChanged();
                }
            })
            .addOnFailureListener(new OnFailureListener()
            {
                @Override
                public void onFailure(@NonNull Exception e)
                {
                    Log.w(TAG, "Error updating document", e);
                }
            });
    }

    private void setClosedFund()
    {
        if (closed) {
            newReceiver.setEnabled(false);
            newReceiver.setText("Closed Fund");
            newReceiver.setBackgroundColor(Color.GRAY);
            addPayment.setEnabled(false);

            final DocumentReference sfDocRef = db.collection("groupFunds").document(groupFundId);

            db.runTransaction(new Transaction.Function<Void>() {
                @Override
                public Void apply(Transaction transaction) throws FirebaseFirestoreException
                {
                    DocumentSnapshot snapshot = transaction.get(sfDocRef);
                    Calendar c = Calendar.getInstance();
                    transaction.update(sfDocRef,"status", "closed");
                    transaction.update(sfDocRef,"star", 1);
                    transaction.update(sfDocRef,"dateEnd", c.getTime());
                    transaction.update(sfDocRef,"duration", Utility.dateFormat(snapshot.getDate("dateStart")) + " - " + Utility.dateFormat(c.getTime()));

                    return null;
                }
            }).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    Log.d(TAG, "Transaction success!");
                    getFundGroupData();
                }
            })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.w(TAG, "Transaction failure.", e);
                        }
                    });
        } else {
            newReceiver.setEnabled(true);
            newReceiver.setText("New Receiver");
            newReceiver.setBackgroundColor(getResources().getColor(R.color.darkGreenButtons));

            DocumentReference dbRef = db.collection("groupFunds").document(groupFundId);
            dbRef
                    .update("status", "active")
                    .addOnSuccessListener(new OnSuccessListener<Void>()
                    {
                        @Override
                        public void onSuccess(Void aVoid)
                        {
                            Log.d(TAG, "DocumentSnapshot successfully updated!");
                            adapter.notifyDataSetChanged();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener()
                    {
                        @Override
                        public void onFailure(@NonNull Exception e)
                        {
                            Log.w(TAG, "Error updating document", e);
                        }
                    });
        }
    }

    private void getFundGroupData()
    {
        new Thread(new Runnable()
        {
            @Override
            public void run()
            {
            final DocumentReference docRef = db.collection("groupFunds").document(groupFundId);
            docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            fundGroup = document.getData();
                            amount = document.getDouble("amount");
                            updateValues();
                            if (document.get("status").equals("closed")) {
                                setClosedFund();
                            }
                            Log.d(TAG, "DocumentSnapshot data: " + document.getData());
                        } else {
                            Log.d(TAG, "No such document");
                        }
                    } else {
                        Log.d(TAG, "get failed with ", task.getException());
                    }
                }
            });
            }
        }).start();
    }

    private void updateValues()
    {
        runOnUiThread(new Runnable()
        {
            @Override
            public void run()
            {
                switch (fundGroup.get("star").toString()) {
                    case "-1": star.setImageResource(R.drawable.ic_star_border_black_24dp);
                        break;
                    case "0": star.setImageResource(R.drawable.ic_star_half_black_24dp);
                        break;
                    case "1": star.setImageResource(R.drawable.ic_star_black_24dp);
                        break;
                    default: star.setImageResource(R.drawable.ic_star_border_black_24dp);
                        break;
                }
                name.setText((fundGroup.containsKey("name")? fundGroup.get("name").toString():""));
                duration.setText((fundGroup.containsKey("duration")? fundGroup.get("duration").toString():""));
                description.setText((fundGroup.containsKey("description")? fundGroup.get("description").toString():""));

                if (fundGroup.get("status").equals("active")) closed = false;
                else closed = true;

                db.collection("payments").whereEqualTo("groupFundId", groupFundId)
                        .get()
                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                paymentCount.setText(task.getResult().size() + " Payments");
                            } else {
                                Log.d(TAG, "Error getting documents: ", task.getException());
                            }
                        }
                    });

                ArrayList<Map<String, Object>> m = ((ArrayList<Map<String, Object>>)fundGroup.get("members"));

                members.clear();
                for (int i=0;i<m.size();i++) {
                    String mId = m.get(i).get("id").toString();
                    if (user.getUid().equals(mId))
                        admin = (boolean)m.get(i).get("admin");
                    m.get(i).put("groupFundId", groupFundId);
                    members.add(m.get(i));
                }
                adminView();

                adapter.notifyDataSetChanged();
            }
        });
    }

    private void adminView() {
        if (admin) {
            addPayment.setVisibility(View.VISIBLE);
            newReceiver.setVisibility(View.VISIBLE);
            updateAdmin.setVisibility(View.VISIBLE);
        } else {
            addPayment.setVisibility(View.INVISIBLE);
            newReceiver.setVisibility(View.INVISIBLE);
            updateAdmin.setVisibility(View.INVISIBLE);
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1)
        {
            Log.d(TAG, "add payment: ");
        } else if (requestCode == 2)
        {
            Log.d(TAG, "new receiver: ");
        }
        else if (requestCode == 3)
        {
            Log.d(TAG, "update admin: ");
        }
        getFundGroupData();
    }

    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }
}
