package com.google.shiongie.sinkingfund;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class GroupFragment extends Fragment
{
    private String TAG = "FUND_GROUP";
    private FirebaseFirestore db;
    private FirebaseUser user;
    private LinearLayout linearLayout;
    private ArrayList<String> linkIds;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_group, container, false);
        ImageButton add = view.findViewById(R.id.group_add);
        db = FirebaseFirestore.getInstance();
        user = FirebaseAuth.getInstance().getCurrentUser();
        linearLayout = view.findViewById(R.id.group_list);
        linkIds = new ArrayList<>();

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(getContext(), AddFundGroupActivity.class);
                startActivityForResult(intent, 1);

            }
        });

        updateGroupFundList();

        return view;
    }

    private void updateGroupFundList() {
        linearLayout.removeAllViews();
        linkIds.clear();
        getActivity().runOnUiThread(new Runnable() {
            public void run() {
                linearLayout.removeAllViews();
                db.collection("groupFunds")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                ArrayList<Map<String, Object>> members = (ArrayList<Map<String, Object>>) document.get("members");
                                boolean show = false;
                                for(int i=0;i<members.size();i++) {
                                    if (members.get(i).containsValue(user.getEmail()) && document.get("status").toString().equals("active")) {
                                        show = true;
                                        break;
                                    }
                                }
                                if (show)
                                {
                                    linkIds.add(document.getId());
                                    TextView fund = new TextView(getContext());
                                    fund.setPadding(20,20,20,20);
                                    fund.setBackground(getResources().getDrawable(R.drawable.custom_linear_list_background));
                                    fund.setText(document.get("name").toString());
                                    fund.setTextSize(TypedValue.COMPLEX_UNIT_SP, 25);
                                    linearLayout.addView(fund);

                                    fund.setOnClickListener(new View.OnClickListener()
                                    {
                                        @Override
                                        public void onClick(View v)
                                        {
                                            Intent intent = new Intent(getContext(), FundViewActivity.class);
                                            intent.putExtra("GROUP_FUND_ID", linkIds.get(linearLayout.indexOfChild(v)));
                                            startActivity(intent);
                                        }
                                    });
                                }
                                Log.d(TAG, document.getId() + " => " + document.getData());
                            }
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                            TextView fund = new TextView(getContext());
                            fund.setText("No Group Funds Found");
                            linearLayout.addView(fund);
                        }
                    }
                });
            }
        });
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1)
        {
            updateGroupFundList();
            Log.d(TAG, "Update List: ");
        }
    }
}
