package com.google.shiongie.sinkingfund;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class HistoryFragment extends Fragment
{

    private FirebaseAuth mAuth;
    private FirebaseUser user;
    private FirebaseFirestore db;
    private HistoryListRecyclerViewAdapter adapter;
    public static final String TAG = "HistoryFragment";
    private int paymentCount = 0;

    private ArrayList<Map<String, Object>> histories;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_history, container, false);
        Log.d(TAG, "onCreate: started");
        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
        user = mAuth.getCurrentUser();
        histories = new ArrayList();

        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.history_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));

        adapter = new HistoryListRecyclerViewAdapter(getContext(), histories);
        recyclerView.setAdapter(adapter);
        return view;
    }
    @Override
    public void onStart() {
        super.onStart();
        if (adapter != null) {
            fillData();
        }

    }

    private void fillData() {
        db.collection("groupFunds")
            .get()
            .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                @Override
                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                    if (task.isSuccessful()) {
                        histories.clear();
                        int j=0;
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            ArrayList<Map<String, Object>> members = ((ArrayList) document.get("members"));
                            boolean isMember = false;
                            for(int i=0;i<members.size();i++) {
                                if (members.get(i).containsValue(user.getEmail())) {
                                    isMember = true;
                                }
                            }
                            if (isMember) {
                                histories.add(document.getData());
                                final Map<String, Object> history = histories.get(j);
                                history.put("groupFundId", document.getId());

                                db.collection("payments")
                                    .whereEqualTo("groupFundId", document.getId())
                                    .whereEqualTo("email", user.getEmail())
                                    .get()
                                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                            if (task.isSuccessful()) {
                                                history.put("paymentCount", task.getResult().size());

                                                adapter.notifyDataSetChanged();
                                            } else {
                                                Log.d(TAG, "Error getting documents: ", task.getException());
                                            }
                                        }
                                    });
                                j++;
                            }
                            Log.d(TAG, document.getId() + " => " + document.getData());
                        }
                    } else {
                        Log.d(TAG, "Error getting documents: ", task.getException());
                    }
                }
            });
    }

}
