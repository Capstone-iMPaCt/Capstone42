package com.google.shiongie.sinkingfund;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class HistoryListRecyclerViewAdapter extends RecyclerView.Adapter<HistoryListRecyclerViewAdapter.ViewHolder>
{
    public static final String TAG = "HistoryListAdapter";

    private Context mContext;
    private ArrayList<Map<String, Object>> histories;
    private FirebaseUser user;

    public HistoryListRecyclerViewAdapter(Context mContext, ArrayList<Map<String, Object>> histories)
    {
        this.histories = histories;
        this.mContext = mContext;
        user = FirebaseAuth.getInstance().getCurrentUser();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(mContext).inflate(R.layout.history_list_item, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position)
    {
        Log.d(TAG, "onBindViewHolder: called.");
        final Map<String, Object> history = histories.get(position);
        switch (history.get("star").toString()) {
            case "-1": holder.star.setImageResource(R.drawable.ic_star_border_black_24dp);
                break;
            case "0": holder.star.setImageResource(R.drawable.ic_star_half_black_24dp);
                break;
            case "1": holder.star.setImageResource(R.drawable.ic_star_black_24dp);
                break;
            default: holder.star.setImageResource(R.drawable.ic_star_border_black_24dp);
                break;
        }
        holder.name.setText((history.containsKey("name")? history.get("name").toString():""));
        holder.duration.setText((history.containsKey("duration")? history.get("duration").toString():""));

        if (history.containsKey("paymentCount")) {
            holder.paymentCount.setText((history.get("paymentCount")).toString() + " payments");
        } else {
            holder.paymentCount.setText("0 payments");
        }

        holder.description.setText((history.containsKey("description")? history.get("description").toString():""));
        ArrayList<Map<String, Object>> members = ((ArrayList<Map<String, Object>>) history.get("members"));
        for (Map<String, Object> member: members)
        {
            if (member.get("email").toString().equals(user.getEmail())) {
                holder.received.setText(((boolean)member.get("received")? "Received":"To Receive"));
                try{
                    holder.dateAction.setText(Utility.dateFormat((Date)member.get("dateReceive")));
                } catch (Exception e) {
                    holder.dateAction.setText(Utility.dateFormat((Timestamp)member.get("dateReceive")));
                }
            }
        }
        holder.parent.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(v.getContext(), FundViewActivity.class);
                intent.putExtra("GROUP_FUND_ID", history.get("groupFundId").toString());
                v.getContext().startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount()
    {
        return histories.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout parent;
        ImageView star;
        TextView name, duration, description, paymentCount, received, dateAction;

        public ViewHolder(@NonNull View itemView)
        {
            super(itemView);
            parent = itemView.findViewById(R.id.list_item_history_parent);
            star = itemView.findViewById(R.id.list_item_history_star);
            name = itemView.findViewById(R.id.list_item_history_name);
            duration = itemView.findViewById(R.id.list_item_history_duration);
            description = itemView.findViewById(R.id.list_item_history_description);
            paymentCount = itemView.findViewById(R.id.list_item_history_payment_count);
            received = itemView.findViewById(R.id.list_item_history_user_action);
            dateAction = itemView.findViewById(R.id.list_item_history_date_action);
        }
    }
}
