package com.google.shiongie.sinkingfund;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class HomeFragment extends Fragment
{
    HomeFragmentListener mListener;
    private FirebaseUser user;

    public interface HomeFragmentListener {
        void changeFragment(int id);
    }

    @Override
    public void onAttach(Context context)
    {
        super.onAttach(context);
        try {
            mListener = (HomeFragmentListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        final Button payment = view.findViewById(R.id.home_payments);
        final Button history = view.findViewById(R.id.home_history);
        final Button group = view.findViewById(R.id.home_fund_group);
        final Button profile = view.findViewById(R.id.home_profile);
        user = FirebaseAuth.getInstance().getCurrentUser();

        payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ViewPaymentsActivity.class);
                intent.putExtra("TYPE", "user");
                intent.putExtra("GROUP_FUND_ID", "");
                intent.putExtra("USER_EMAIL", user.getEmail());
                startActivity(intent);
            }
        });
        history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.changeFragment(R.id.nav_history);
            }
        });
        group.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.changeFragment(R.id.nav_fund_groups);
            }
        });
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.changeFragment(R.id.nav_profile);
            }
        });
        return view;
    }
}
