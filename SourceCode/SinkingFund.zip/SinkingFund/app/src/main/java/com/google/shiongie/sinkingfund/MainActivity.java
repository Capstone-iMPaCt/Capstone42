package com.google.shiongie.sinkingfund;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.Locale;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, HomeFragment.HomeFragmentListener, ProfileFragment.ProfileFragmentListener
{
    private DrawerLayout drawer;
    private Toolbar toolbar;
    private NavigationView navigationView;
    private FirebaseAuth mAuth;
    private FirebaseUser user;
    private FirebaseStorage storage;
    private StorageReference storageRef;
    private View headerView;
    private ImageView image;
    public static Locale currentLocale;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        currentLocale = getResources().getConfiguration().locale;

        ref();

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toogle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toogle);
        toogle.syncState();

        if (savedInstanceState == null)
        {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
        }

        if (user != null)
        {
            setTitle(user.getDisplayName());

            TextView username = (TextView) headerView.findViewById(R.id.nav_drawer_username);
            TextView email = (TextView) headerView.findViewById(R.id.nav_drawer_email);

            username.setText(user.getDisplayName());
            email.setText(user.getEmail());
            changeProfileImage();

        } else {
            signOut();
        }
    }

    @Override
    public void onBackPressed()
    {
        if (drawer.isDrawerOpen(GravityCompat.START))
        {
            drawer.closeDrawer(GravityCompat.START);
        } else if (navigationView.getCheckedItem().getItemId()!=R.id.nav_home) {
            changeFragment(R.id.nav_home);
        }
        else
        {
            super.onBackPressed();
        }
    }

    public void ref()
    {
        mAuth = FirebaseAuth.getInstance();
        user = mAuth.getCurrentUser();
        storage = FirebaseStorage.getInstance();
        storageRef = storage.getReference();
        toolbar = findViewById(R.id.toolbar);
        drawer = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        headerView = navigationView.getHeaderView(0);
        image = (ImageView) headerView.findViewById(R.id.nav_image);
    }

    public void signOut(View v) {
        signOut();
    }

    private void signOut() {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(this, SignInActivity.class);
        startActivity(intent);
        this.finish();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem)
    {
        changeFragment (menuItem.getItemId());
        drawer.closeDrawer(GravityCompat.START);

        return true;
    }

    @Override
    public void changeFragment(final int id){
        runOnUiThread(new Runnable() {
            public void run() {
                switch (id)
                {
                    case R.id.nav_home:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
                        navigationView.setCheckedItem(R.id.nav_home);
                        break;
                    case R.id.nav_fund_groups:
                    case R.id.home_fund_group:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new GroupFragment()).commit();
                        navigationView.setCheckedItem(R.id.nav_fund_groups);
                        break;
                    case R.id.nav_payments:
                    case R.id.home_payments:
                        Intent intent = new Intent(MainActivity.this, ViewPaymentsActivity.class);
                        intent.putExtra("TYPE", "user");
                        intent.putExtra("GROUP_FUND_ID", "");
                        intent.putExtra("USER_EMAIL", user.getEmail());
                        startActivity(intent);
                        navigationView.setCheckedItem(R.id.nav_payments);
                        break;
                    case R.id.nav_profile:
                    case R.id.home_profile:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new ProfileFragment()).commit();
                        navigationView.setCheckedItem(R.id.nav_profile);
                        break;
                    case R.id.nav_history:
                    case R.id.home_history:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HistoryFragment()).commit();
                        navigationView.setCheckedItem(R.id.nav_history);
                        break;
                    case R.id.nav_logout:
                        signOut();
                        break;
                }
            }
        });
    }

    @Override
    public void changeProfileImage() {
        new Thread(new Runnable() {
            public void run() {
                if(user.getPhotoUrl()!=null)
                {
                    storageRef.child("images").child(user.getUid()).getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            Picasso.get().load(uri.toString()).transform(new CircleTransform()).error(R.drawable.user).into(image);
                        }
                    });
                }
            }
        }).start();
    }
}
