package com.google.shiongie.sinkingfund;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.firebase.Timestamp;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class PaymentListRecyclerViewAdapter extends RecyclerView.Adapter<PaymentListRecyclerViewAdapter.ViewHolder>
{
    public static final String TAG = "PaymentListAdapter";

    private Context mContext;
    private ArrayList<Map<String, Object>> payments;

    public PaymentListRecyclerViewAdapter(Context mContext, ArrayList<Map<String, Object>> payments)
    {
        this.payments = payments;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(mContext).inflate(R.layout.view_payment_item, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position)
    {
        Log.d(TAG, "onBindViewHolder: called.");

        final Map<String, Object> payment = payments.get(position);
        holder.groupFund.setText((payment.containsKey("groupFund")? payment.get("groupFund").toString():""));
        holder.email.setText((payment.containsKey("email")? payment.get("email").toString():""));
        holder.amount.setText((payment.containsKey("amount")? Utility.currencyFormat((double)payment.get("amount")):""));

        SimpleDateFormat sfd = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
        holder.date.setText(sfd.format(((Timestamp)payment.get("datePaid")).toDate()));

    }

    @Override
    public int getItemCount()
    {
        return payments.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout parent;
        TextView groupFund, email, amount, date;

        public ViewHolder(@NonNull View itemView)
        {
            super(itemView);
            parent = itemView.findViewById(R.id.view_payment_parent);
            groupFund = itemView.findViewById(R.id.view_payment_fund_name);
            email = itemView.findViewById(R.id.view_payment_user_email);
            amount = itemView.findViewById(R.id.view_payment_amount);
            date = itemView.findViewById(R.id.view_payment_date);
        }
    }
}

