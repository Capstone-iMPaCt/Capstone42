package com.google.shiongie.sinkingfund;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import static android.app.Activity.RESULT_OK;

public class ProfileFragment extends Fragment
{
    private FirebaseAuth mAuth;
    private FirebaseUser user;
    private StorageReference storageRef;
    private StorageReference ref;
    private ImageView profileImage;
    private final int PICK_IMAGE_REQUEST = 71;
    private Uri filePath;

    ProfileFragmentListener mListener;

    public interface ProfileFragmentListener {
        void changeProfileImage();
    }

    @Override
    public void onAttach(Context context)
    {
        super.onAttach(context);
        try {
            mListener = (ProfileFragmentListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement ProfileFragmentListener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        final ImageButton changeImage = view.findViewById(R.id.profile_change_image);
        final Button changePassword = view.findViewById(R.id.profile_change_password);
        final TextView username = view.findViewById(R.id.profile_username);
        final TextView email = view.findViewById(R.id.profile_email);
        final EditText oldPass = view.findViewById(R.id.profile_old_pass);
        final EditText newPass = view.findViewById(R.id.profile_new_pass);
        final EditText confirmPass = view.findViewById(R.id.profile_confirm_pass);
        final CheckBox showPassword = view.findViewById(R.id.profile_show_password);

        profileImage = view.findViewById(R.id.profile_image);
        mAuth = FirebaseAuth.getInstance();
        user = mAuth.getCurrentUser();
        storageRef = FirebaseStorage.getInstance().getReference();

        username.setText(user.getDisplayName());
        email.setText(user.getEmail());
        if(user.getPhotoUrl()!=null)
        {
            storageRef.child("images").child(user.getUid()).getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                @Override
                public void onSuccess(Uri uri) {
                    Picasso.get().load(uri.toString()).error(R.drawable.user).into(profileImage);
                }
            });
        }
        changeImage.setOnClickListener(selectphoto);

        showPassword.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                if (isChecked)
                {
                    oldPass.setTransformationMethod(null);
                    newPass.setTransformationMethod(null);
                    confirmPass.setTransformationMethod(null);
                }
                else
                {
                    oldPass.setTransformationMethod(new PasswordTransformationMethod());
                    newPass.setTransformationMethod(new PasswordTransformationMethod());
                    confirmPass.setTransformationMethod(new PasswordTransformationMethod());
                }
            }
        });
        changePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            new Thread(new Runnable() {
                public void run() {
                    if (confirmPass.getText().toString().equals(newPass.getText().toString())) {
                        if (!(newPass.getText().toString().isEmpty() || oldPass.getText().toString().isEmpty()))
                        {
                            AuthCredential credential = EmailAuthProvider.getCredential(user.getEmail(),oldPass.getText().toString());
                            user.reauthenticate(credential).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful()){
                                    user.updatePassword(newPass.getText().toString()).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                        if(!task.isSuccessful()){
                                            Toast.makeText(getContext(), "Something went wrong. Please try again later",
                                                    Toast.LENGTH_SHORT).show();
                                        }else {
                                            Toast.makeText(getContext(), "Password Successfully Modified",
                                                    Toast.LENGTH_SHORT).show();
                                            oldPass.setText("");
                                            newPass.setText("");
                                            confirmPass.setText("");
                                        }
                                        }
                                    });
                                } else
                                {
                                    Toast.makeText(getContext(), "Wrong old password",
                                            Toast.LENGTH_SHORT).show();
                                }
                                }
                            });
                        } else {
                            Toast.makeText(getContext(), "No password given",
                                    Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getContext(), "Mismatch new and confirm password",
                                Toast.LENGTH_SHORT).show();
                    }
                }
            }).start();
            }
        });

        return view;
    }

    private View.OnClickListener selectphoto = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            new Thread(new Runnable() {
                public void run() {
                    Intent i = new Intent(Intent.ACTION_PICK,
                            android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(i, PICK_IMAGE_REQUEST);
                }
            }).start();
        }
    };

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null )
        {
            filePath = data.getData();;
            try {
                String[] filePathColumn = { MediaStore.Images.Media.DATA };

                Cursor cursor = getContext().getContentResolver().query(filePath,
                        filePathColumn, null, null, null);
                cursor.moveToFirst();

                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                String picturePath = cursor.getString(columnIndex);
                cursor.close();

                Bitmap bitmap = BitmapFactory.decodeFile(picturePath);
                profileImage.setImageBitmap(bitmap);
                uploadImage(user.getUid());
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }

    public void uploadImage(String txtid){
        if(filePath != null)
        {
            final ProgressDialog progressDialog = new ProgressDialog(getContext());
            progressDialog.setTitle("Uploading...");
            progressDialog.show();

            ref = storageRef.child("images/"+ txtid);
            ref.putFile(filePath)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    progressDialog.dismiss();
                                    showAlert("Successfully Added","Success");
                                    updateUserProfile(uri);
                                }
                            });
                        }
                    })
                    .   addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();
                            showAlert("An Error Occured","ERROR");
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0*taskSnapshot.getBytesTransferred()/taskSnapshot
                                    .getTotalByteCount());
                            progressDialog.setMessage("Uploaded "+(int)progress+"%");
                        }
                    });
        }
    }

    public void showAlert(String Message,String label)
    {
        //set alert for executing the task
        AlertDialog.Builder alert = new AlertDialog.Builder(getContext());
        alert.setTitle(""+label);
        alert.setMessage(""+Message);

        alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick (DialogInterface dialog, int id){
                dialog.cancel();
            }
        });

        Dialog dialog = alert.create();
        dialog.show();
    }

    public void updateUserProfile(Uri photoUri) {
        UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                .setPhotoUri(photoUri)
                .build();

        user.updateProfile(profileUpdates)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Log.d(null, "User profile updated.");
                        }
                    }
                });

    }
}
