package com.google.shiongie.sinkingfund;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class UpdateAdminActivity extends AppCompatActivity
{
    private String TAG = "Update_Admin";
    private FirebaseFirestore db;
    private UpdateAdminRecyclerViewAdapteer adapter;

    private String id;
    private Button update;
    private ArrayList<Map<String, Object>> members;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_admin);

        Intent intent = getIntent();
        id = intent.getStringExtra("GROUP_FUND_ID");

        db = FirebaseFirestore.getInstance();

        update = findViewById(R.id.ua_update_admin);

        members = new ArrayList<>();

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.ua_member_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new UpdateAdminRecyclerViewAdapteer(this, members);
        recyclerView.setAdapter(adapter);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getMembers();

        update.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Map<String, Boolean> admins = adapter.getAdmins();

                if(admins.containsValue(true))
                {
                    for (int i = 0; i < members.size(); i++)
                    {
                        Map<String, Object> m = members.get(i);
                        if (m.get("admin") != admins.get(m.get("id")))
                            m.put("admin", admins.get(m.get("id")));
                    }
                    DocumentReference dbRef = db.collection("groupFunds").document(id);
                    dbRef
                            .update("members", members)
                            .addOnSuccessListener(new OnSuccessListener<Void>()
                            {
                                @Override
                                public void onSuccess(Void aVoid)
                                {
                                    finish();
                                    Log.d(TAG, "DocumentSnapshot successfully updated!");
                                }
                            })
                            .addOnFailureListener(new OnFailureListener()
                            {
                                @Override
                                public void onFailure(@NonNull Exception e)
                                {
                                    Log.w(TAG, "Error updating document", e);
                                }
                            });
                } else {
                    Toast.makeText(UpdateAdminActivity.this, "No Admin Selected",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void getMembers()
    {
        new Thread(new Runnable()
        {
            @Override
            public void run()
            {
                DocumentReference docRef = db.collection("groupFunds").document(id);
                docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                                ArrayList<Map<String, Object>> m = ((ArrayList<Map<String, Object>>)document.get("members"));
                                for (int i=0;i<m.size();i++) {
                                    members.add(m.get(i));
                                }
                                Log.d(TAG, "DocumentSnapshot data: " + document.getData());
                            } else {
                                Log.d(TAG, "No such document");
                            }
                            adapter.notifyDataSetChanged();
                        } else {
                            Log.d(TAG, "get failed with ", task.getException());
                        }
                    }
                });
            }
        }).start();
    }

    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }
}
