package com.google.shiongie.sinkingfund;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class UpdateAdminRecyclerViewAdapteer extends RecyclerView.Adapter<UpdateAdminRecyclerViewAdapteer.ViewHolder>
{
    public static final String TAG = "FundMemberAdapter";

    private Map<String, Boolean> admins;
    private Context mContext;
    private ArrayList<Map<String, Object>> members;

    public UpdateAdminRecyclerViewAdapteer(Context mContext, ArrayList<Map<String, Object>> members)
    {
        this.admins = new HashMap<>();
        this.members = members;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(mContext).inflate(R.layout.update_admin_member_item, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position)
    {
        Log.d(TAG, "onBindViewHolder: called.");

        final FirebaseFirestore db = FirebaseFirestore.getInstance();

        final Map<String, Object> member = members.get(position);
        holder.name.setText((member.containsKey("name")? member.get("name").toString():""));
        holder.email.setText((member.containsKey("email")? member.get("email").toString():""));
        holder.adminSwitch.setChecked((member.containsKey("admin")? (boolean)member.get("admin") : false));
        admins.put(member.get("id").toString(), (boolean)member.get("admin"));
        holder.adminSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                admins.put(member.get("id").toString(), isChecked);
            }
        });
    }

    @Override
    public int getItemCount()
    {
        return members.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout parent;
        TextView name, email;
        Switch adminSwitch;

        public ViewHolder(@NonNull View itemView)
        {
            super(itemView);
            parent = itemView.findViewById(R.id.list_item_history_parent);
            name = itemView.findViewById(R.id.ua_member_name);
            email = itemView.findViewById(R.id.ua_member_email);
            adminSwitch = itemView.findViewById(R.id.ua_admin_switch);
        }
    }
    public Map<String, Boolean> getAdmins() {
        return admins;
    }
}
