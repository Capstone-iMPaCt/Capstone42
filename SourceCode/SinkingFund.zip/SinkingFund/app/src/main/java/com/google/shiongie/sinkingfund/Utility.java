package com.google.shiongie.sinkingfund;

import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Currency;
import java.util.Date;
import java.util.Locale;

public class Utility
{
    private static String TAG = "Utility";
    private static FirebaseFirestore db = FirebaseFirestore.getInstance();
    private static FirebaseAuth mAuth = FirebaseAuth.getInstance();
    private static FirebaseUser user = mAuth.getCurrentUser();

    public static String dateFormat(Date date) {
        SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
        return format.format(date);
    }
    public static String dateFormat(Timestamp date) {
        SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
        return format.format(date.toDate());
    }

    public static String currencyFormat(double num) {
        NumberFormat format = NumberFormat.getCurrencyInstance();
        format.setMaximumFractionDigits(2);
        format.setMinimumFractionDigits(2);
        if (MainActivity.currentLocale!=null)
            format.setCurrency(Currency.getInstance(MainActivity.currentLocale));
        else
            format.setCurrency(Currency.getInstance(Locale.getDefault()));
        return format.format(num);
    }
    public static Calendar addDate(Calendar c, String type, int amount) {
        switch (type) {
            case "Daily":
                c.add(Calendar.DAY_OF_MONTH, amount);
                break;
            case "Weekly":
                c.add(Calendar.WEEK_OF_YEAR, amount);
                break;
            case "Monthly":
                c.add(Calendar.MONTH, amount);
                break;
            case "Yearly":
                c.add(Calendar.YEAR, amount);
                break;
        }
        return c;
    }
}
