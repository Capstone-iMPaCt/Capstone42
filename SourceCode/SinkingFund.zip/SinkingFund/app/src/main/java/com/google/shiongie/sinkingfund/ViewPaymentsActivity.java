package com.google.shiongie.sinkingfund;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ViewPaymentsActivity extends AppCompatActivity
{
    private String TAG = "View_Payments";
    private FirebaseFirestore db;
    private FirebaseUser user;
    private PaymentListRecyclerViewAdapter adapter;

    private String type;
    private String groupFundId;
    private String email;
    private String titleAppend;

    private TextView title;

    private Map<String, Map<String, Object>> fundGroups;
    private ArrayList<Map<String, Object>> payments;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_payments);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        db = FirebaseFirestore.getInstance();
        user = FirebaseAuth.getInstance().getCurrentUser();

        title = findViewById(R.id.view_payment_title);
        titleAppend = "Payments";

        fundGroups = new HashMap<>();
        payments = new ArrayList<>();

        Intent intent = getIntent();
        type = intent.getStringExtra("TYPE");
        groupFundId = intent.getStringExtra("GROUP_FUND_ID");
        email = intent.getStringExtra("USER_EMAIL");

        if (type.equals("user")) {
            getUsername();
        } else if (type.equals("groupFund")){
            getGroupFundName();
        } else {
            getUsername();
        }

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.view_payment_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new PaymentListRecyclerViewAdapter(this, payments);
        recyclerView.setAdapter(adapter);

        getAllGroupFunds();
    }

    private void getUsername()
    {
        db.collection("users")
            .whereEqualTo("email", email)
            .get()
            .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                @Override
                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                    if (task.isSuccessful()) {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            titleAppend +=" by " + document.get("name").toString();
                            if (type.equals("user"))
                                title.setText(titleAppend);
                            else
                                getGroupFundName();
                            Log.d(TAG, document.getId() + " => " + document.getData());
                        }
                    } else {
                        Log.d(TAG, "Error getting documents: ", task.getException());
                    }
                }
            });
    }

    private void getGroupFundName()
    {
        DocumentReference docRef = db.collection("groupFunds").document(groupFundId);
        docRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                titleAppend += " for " + documentSnapshot.get("name").toString();
                title.setText(titleAppend);
            }
        });
    }

    private void getAllGroupFunds()
    {
        db.collection("groupFunds")
            .get()
            .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                @Override
                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    fundGroups.clear();
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        fundGroups.put(document.getId(), document.getData());
                        Log.d(TAG, document.getId() + " => " + document.getData());
                    }
                    getAllPayments();
                } else {
                    Log.d(TAG, "Error getting documents: ", task.getException());
                }
                }
            });
    }

    private void getAllPayments()
    {
        payments.clear();
        CollectionReference paymentsRef = db.collection("payments");
        paymentsRef.orderBy("datePaid", Query.Direction.DESCENDING);
        paymentsRef.get()
            .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                @Override
                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                    if (task.isSuccessful()) {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            if (email.equals("") && !groupFundId.equals("")) {
                                Map<String, Object> payment = new HashMap<>();
                                payment.putAll(document.getData());
                                payment.put("groupFund", fundGroups.get(groupFundId).get("name"));
                                payment.put("email", document.get("email"));
                                System.out.println(payment.toString());
                                if (document.get("groupFundId").equals(groupFundId))
                                    payments.add(payment);
                            } else if (!email.equals("") && groupFundId.equals("")) {
                                Map<String, Object> payment = new HashMap<>();
                                payment.putAll(document.getData());
                                payment.put("groupFund", fundGroups.get(document.get("groupFundId")).get("name"));
                                payment.put("email", email);
                                System.out.println(payment.toString());
                                if (document.get("email").equals(email))
                                    payments.add(payment);
                            } else if(!email.equals("") && !groupFundId.equals("")) {
                                Map<String, Object> payment = new HashMap<>();
                                payment.putAll(document.getData());
                                payment.put("groupFund", fundGroups.get(groupFundId).get("name"));
                                payment.put("email", email);
                                System.out.println(payment.toString());
                                if (document.get("email").equals(email) && document.get("groupFundId").equals(groupFundId))
                                    payments.add(payment);
                            } else {
                                Map<String, Object> payment = new HashMap<>();
                                payment.putAll(document.getData());
                                payment.put("groupFund", fundGroups.get(document.get("groupFundId")).get("name"));
                                payment.put("email", document.get("email"));
                                System.out.println(payment.toString());
                                payments.add(payment);
                            }
                            Log.d(TAG, document.getId() + " => " + document.getData());
                        }
                        adapter.notifyDataSetChanged();
                    } else {
                        Log.d(TAG, "Error getting documents: ", task.getException());
                    }
                }
            });
    }

    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }
}
