package com.project.ilearncentral.CustomInterface;

public interface OnObjectChangeListener {
    public void onChanged(Object value);
}
