package com.project.ilearncentral.CustomInterface;

public interface OnStringChangeListener {
        public void onStringChanged(String value);
}
