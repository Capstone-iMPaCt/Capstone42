firebase.auth().onAuthStateChanged(function(user) {
  if (user) {
    // User is signed in.
      document.getElementById("feedPage").style.display ="block";
      document.getElementById("loginPage").style.display ="none";
  } else {
    // No user is signed in.
      document.getElementById("feedPage").style.display ="none";
      document.getElementById("loginPage").style.display ="block";
  }
});

function login()
{
    var userEmail = document.getElementById("user_email").value;
    var userPass = document.getElementById("user_pass").value;
    
    firebase.auth().signInWithEmailAndPassword(userEmail, userPass)
        .then((user) => {
    // Signed in 
    // ...
        })
  .catch((error) => {
    var errorCode = error.code;
    var errorMessage = error.message;
        
        window.alert("Error !!" errorMessage);
  });
    
    
}